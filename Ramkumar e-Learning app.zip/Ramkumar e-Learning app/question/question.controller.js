app.controller('QuestionController',function($scope,$rootScope){
    
       $scope.question = $rootScope.questionDisplay;
       
});