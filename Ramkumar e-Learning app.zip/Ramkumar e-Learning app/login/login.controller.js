﻿app.controller('LoginController',function($scope,$location,$rootScope){
    $scope.submit = function(){
       
        if($scope.username == "ramkumar" && $scope.password == "ramkumar"){
            $rootScope.loggedIn = true;
            $location.path('/search');
        }else{
            alert("Wrong User")
        }
    }
});


