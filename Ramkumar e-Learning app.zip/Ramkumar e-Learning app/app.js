﻿var app = angular.module('app',['ngRoute']);

app.config(function($routeProvider){
    $routeProvider
            .when('/', {
                controller: 'LoginController',
                templateUrl: 'login/login.view.html'
            })
            .when('/search', {
                resolve:{
                    "check": function($rootScope,$location){
                        if(!$rootScope.loggedIn){
                            $location.path('/');
                        }
                    }
                },
                controller: 'SearchController',
                templateUrl: 'search/search.view.html'
            })
            .when('/question', {
                resolve:{
                    "check": function($rootScope,$location){
                        if(!$rootScope.loggedIn){
                            $location.path('/');
                        }
                    }
                },
                controller: 'QuestionController',
                templateUrl: 'question/question.view.html'
            })

            .otherwise({ redirectTo: '/' });
});
