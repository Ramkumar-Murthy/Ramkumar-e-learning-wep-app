﻿var questionnaire = {
    "questions": [
        {
            "id": 1,
            "questionText": "Who is the President of India?",
            "answerOptions": ["Ram Nath Kovind","Narendra Modi"],
            "correctAnswer": "Ram Nath Kovind",
            "author": "Wikipedia",
            "stats": ["13th Oct 2020","4","98%"] 
        },
        {
            "id": 2,
            "questionText": "Which is the Capital of India?",
            "answerOptions": ["Mumbai","Delhi"],
            "correctAnswer": "Delhi",
            "author": "Wikipedia",
            "stats": ["30th Oct 2020","5","99%"] 
        }
        
    ]
}
app.controller('SearchController',function($scope,$rootScope,$location){
    $scope.editSearch = function(){
        $scope.editTrue = true;
        $scope.enterSubmit = false;
    };
    $scope.submit = function(){
        $scope.enterSubmit = true;
        $scope.question = questionnaire.questions;
    };
    $scope.findQuestion = function(question){
        $rootScope.questionDisplay = question;
        $location.path('/question');
    };
});

